/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_interfaces2;

/**
 *
 * @author Adrian
 */
public class Ejercicio_interfaces2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FiguraDibujable circulo = new CirculoDibujable();
        FiguraDibujable cuadrado = new CuadradoDibujable();
        
        circulo.dibujar();
        cuadrado.dibujar();
    }
    
}
