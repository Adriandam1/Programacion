/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio_interfaces2;

/**
 *
 * @author Adrian
 */
public class CirculoDibujable implements FiguraDibujable{
    
    @Override
    public void dibujar(){
            System.out.println("Dibujando circulo");
}
    
}
