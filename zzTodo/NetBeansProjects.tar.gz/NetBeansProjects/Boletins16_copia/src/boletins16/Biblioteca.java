/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boletins16;

/**
 *
 * @author Adrian
 */
public class Biblioteca {
    Libro libro;
    Revista revista;

    public Biblioteca() {
    }

    public Biblioteca(Libro libro, Revista revista) {
        this.libro = libro;
        this.revista = revista;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    public Revista getRevista() {
        return revista;
    }

    public void setRevista(Revista revista) {
        this.revista = revista;
    }

    @Override
    public String toString() {
        return "Biblioteca{" + "libro=" + libro + ", revista=" + revista + '}';
    }   
    
    public void amosarLibro(Libro libro){
        Libro obxL = new Libro(true, 5, "El señor de los anillos", 1960);
        System.out.println(obxL);
    }
    
}
