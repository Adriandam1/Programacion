
package datos;

import javax.swing.JOptionPane;

/**
 *
 * @author Adrian
 */
public class LerDatos {
    
    public static int lerEnteiro (String mensaxe){
        int resposta = Integer.parseInt(JOptionPane.showInputDialog(mensaxe));
        return resposta;
        
     //   tamen seria o mesmo
     //   return Integer.parseInt(JOptionPane.showInputDialog(mensaxe))
    }
    
}
