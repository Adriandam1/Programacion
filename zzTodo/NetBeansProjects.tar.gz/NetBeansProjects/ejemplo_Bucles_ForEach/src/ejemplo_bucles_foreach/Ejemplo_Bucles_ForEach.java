/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo_bucles_foreach;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Adrian
 */
public class Ejemplo_Bucles_ForEach {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        List<String> frutas= new ArrayList<>();
        frutas.add("Pera");
        frutas.add("Manzana");
        frutas.add("Platano");
        frutas.add("Mandarina");
    
        // recorriendo el ArrayList con un for normal
        for (int i=0;i<frutas.size();i++) {      
        System.out.println(frutas.get(i));
      
      
    }
        System.out.println("----------------------");
    //Recorriendo el ArrayList con el for each (siempre recorre todo el array)
         for(String cadena :frutas) {
      System.out.println(cadena);
    }
         
         
         
         
         System.out.println("-------------------------------");
         //Array unidimensional con bucle for each
         String lista[] = {"hola","que", "tal","estas"};
         for (String cadena: lista){
             System.out.println(cadena);
         }
         
    }
    
}
