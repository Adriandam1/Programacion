/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemploclaseide;

/**
 *
 * @author Adrian
 */
public class Rectangulo {
    float base;
    float altura;
    
    public Rectangulo(){    
    }
    
    public Rectangulo(float ba, float al){
        base = ba;
        altura = al;
    }
    
    public float getBase(){
        return base;
    }
    public float getAltura(){
        return altura;
    }
    public void setBase(float ba){
        base = ba;

    }
    public void setAltura(float al){
        altura = al;
        
    }
    
    
    public void calcularArea(float ba, float al){
        float area = ba * al;
        System.out.println("area = "+area);
    }
    public float calcularPerimetro(float ba, float al){
        float peri = 2 * ba + 2 * al;
        return peri;
    }
    
}
