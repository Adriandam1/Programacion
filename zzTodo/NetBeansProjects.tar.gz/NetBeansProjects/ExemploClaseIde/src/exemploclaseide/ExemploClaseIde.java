/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemploclaseide;

/**
 *
 * @author Adrian
 */
public class ExemploClaseIde {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Rectangulo1 obx = new Rectangulo1(5, 9);
       /* 
        System.out.println(obx);
        
        System.out.println(obx.toString());
        */
        
        obx.calcularArea(10, 4);
        float res =obx.calcularPerimetro();
        System.out.println("perimetro : "+res);
        
        
    }
    
}
