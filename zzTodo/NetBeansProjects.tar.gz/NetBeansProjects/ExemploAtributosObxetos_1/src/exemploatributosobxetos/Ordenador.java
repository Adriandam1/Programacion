/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemploatributosobxetos;

/**
 *
 * @author Adrian
 */
public class Ordenador {
    private Teclado tecla;
    private Rato raton;
    private Monitor pantaia;
    private Cpu cpu;
    private float precio;

    public Ordenador() {
    }

    public Ordenador(Teclado tecla, Rato raton, Monitor pantaia, Cpu cpu, float precio) {
        this.tecla = tecla;
        this.raton = raton;
        this.pantaia = pantaia;
        this.cpu = cpu;
        this.precio = precio;
    }    

    public Teclado getTecla() {
        return tecla;
    }

    public void setTecla(Teclado tecla) {
        this.tecla = tecla;
    }

    public Rato getRaton() {
        return raton;
    }

    public void setRaton(Rato raton) {
        this.raton = raton;
    }

    public Monitor getPantaia() {
        return pantaia;
    }

    public void setPantaia(Monitor pantaia) {
        this.pantaia = pantaia;
    }

    public Cpu getCpu() {
        return cpu;
    }

    public void setCpu(Cpu cpu) {
        this.cpu = cpu;
    }
    

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Ordenador{" + "tecla=" + tecla + ", raton=" + raton + ", pantaia=" + pantaia + ", cpu=" + cpu + ", precio=" + precio + '}';
    }
    
    public void amosar(Ordenador or){
        System.out.println(or);
    }
    public Ordenador devolver(){
        Ordenador obx = new Ordenador(new Teclado("qqq", 60f), new Rato("rara"), new Monitor("marca", 30), new Cpu(4,5), 500f);
        //return obx;
        return this; // tamen podemos devolver o obxeto con a palabra this
    }
     
}
