/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemploatributosobxetos;

/**
 *
 * @author Adrian
 */
public class Cpu {
    private int velocidade;
    private int almacenamento;

    public Cpu() {
    }

    public Cpu(int velocidade, int almacenamento) {
        this.velocidade = velocidade;
        this.almacenamento = almacenamento;
    }

    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }

    public int getAlmacenamento() {
        return almacenamento;
    }

    public void setAlmacenamento(int almacenamento) {
        this.almacenamento = almacenamento;
    }

    @Override
    public String toString() {
        return "Cpu{" + "velocidade=" + velocidade + ", almacenamento=" + almacenamento + '}';
    }
    
            
}
