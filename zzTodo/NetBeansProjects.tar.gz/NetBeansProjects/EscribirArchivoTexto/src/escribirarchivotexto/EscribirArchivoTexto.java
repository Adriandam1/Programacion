/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package escribirarchivotexto;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EscribirArchivoTexto {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Definir el nombre del archivo donde se guardarán las tareas
        String nombreArchivo = "tareas.txt";
        
        try {
            // Crear un objeto FileWriter para escribir en el archivo (sobrescribe el archivo si ya existe)
            FileWriter fw = new FileWriter(nombreArchivo);
            
            // Envolver el FileWriter en BufferedWriter para una escritura más eficiente
            BufferedWriter bw = new BufferedWriter(fw);
            
            // Escribir algunas tareas en el archivo
            bw.write("1. Hacer la compra\n");
            bw.write("2. Estudiar para el examen de programación\n");
            bw.write("3. Llamar al dentista para agendar una cita\n");
            // Escribir usando la funciona scanner
            System.out.println("Escribe lo que quieras en el txt: ");
            bw.write(sc.nextLine());
            
            // Cerrar el BufferedWriter y FileWriter para finalizar la escritura y guardar los cambios
            bw.close();
        } catch (IOException e) {
            // Capturar y mostrar errores que puedan ocurrir durante la escritura
            System.out.println("Ocurrió un error al escribir en el archivo: " + e.getMessage());
        }
    }
}