/*
 Enunciado 1: Leer un Diario Personal
Objetivo: Crear un programa en Java que lea un archivo de texto llamado "diario.txt", que contiene entradas de un diario personal. Cada entrada está separada por líneas. El programa debe imprimir todas las entradas en la consola.

Descripción:

El archivo "diario.txt" ya existe y contiene varias entradas de diario separadas por líneas.
El programa debe abrir este archivo, leer su contenido línea por línea y mostrar cada entrada en la consola.
Asegúrate de cerrar el archivo después de leerlo.
Sugerencias:

Usa FileReader y BufferedReader para abrir y leer el archivo.
Utiliza un bucle while para leer el archivo hasta que no haya más líneas.
Maneja las excepciones que puedan ocurrir, como FileNotFoundException o IOException.
 */
package ejercicio_1_repaso_lectura_ficheros;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Adrian
 */
public class Ejercicio_1_repaso_lectura_ficheros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Ruta al archivo que queremos leer
        String rutaArchivo = "/home/dam/Escritorio/diario.txt";

        try {
            // Abrir el archivo para leerlo
            FileReader fr = new FileReader(rutaArchivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            
            // Leer el archivo línea por línea
            while ((linea = br.readLine()) != null) {
                System.out.println(linea); // Imprimir cada línea
            }
            
            // Cerrar el archivo
            br.close();
        } catch (IOException e) {
            // Si ocurre un error, imprimir el mensaje de error
            System.out.println("Error leyendo el archivo: " + e.getMessage());
        }
    }
    
}
