package excepciones;


import java.util.Scanner;

 

public class Excepciones {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int numero;

        boolean entradaValida = false;

 

        while (!entradaValida) {

            try {

                System.out.print("Introduce un número entre 0 y 100: ");

                numero = Integer.parseInt(scanner.nextLine());

 

                if (numero < 0 || numero > 100) {

                    throw new IllegalArgumentException("Número fuera de rango.");

                }

 

            System.out.println("Número introducido correctamente: " + numero);

                entradaValida = true;

            } catch (NumberFormatException e) {

                System.out.println("No es un número válido. Por favor, intenta de nuevo.");

            } catch (IllegalArgumentException e) {

                System.out.println(e.getMessage() + " Por favor, intenta de nuevo.");

            }

        }

    }

}

