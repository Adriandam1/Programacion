/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculo2numeros;
import java.util.Scanner;

/**
 *
 * @author dam1
 */
public class Calculo2numeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("Introduce dos numeros enteros:  ");
        Scanner input = new Scanner(System.in);
        int num1 = input.nextInt();
        int num2 = input.nextInt();
        int suma = num1+num2;
        int resta = num1-num2;
        double div = (float)num1/num2;
        int mod = num1%num2;
        int mult = num1*num2;
        System.out.println("La suma: "+num1+" + "+num2+" = "+suma);
        System.out.println("La resta: "+num1+" - "+num2+" = "+resta);
        System.out.println("La division: "+num1+" / "+num2+" =  "+div);
        System.out.println("El modulo: "+num1+" % "+num2+" = "+mod);
        System.out.println("La multiplicacion: "+num1+" * "+num2+" = "+mult);
    }
    
}
