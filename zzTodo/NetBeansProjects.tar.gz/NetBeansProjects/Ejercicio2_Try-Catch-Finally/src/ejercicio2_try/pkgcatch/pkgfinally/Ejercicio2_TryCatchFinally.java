/*
Enunciado 2: Manejo de Archivos
Objetivo: Utilizar try-catch-finally para manejar excepciones al trabajar con archivos en Java.

Descripción:

Intenta abrir un archivo para lectura (puedes usar un nombre de archivo ficticio o uno real si prefieres trabajar con archivos).
Usa un bloque try para abrir el archivo con FileReader y leer su contenido.
Usa un bloque catch para capturar una FileNotFoundException y notifica al usuario que el archivo no se encontró.
En el bloque finally, incluye código para cerrar el archivo si este se abrió exitosamente, asegurándote de manejar cualquier excepción que pueda surgir durante el cierre del archivo.
 */
package ejercicio2_try.pkgcatch.pkgfinally;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

/**
 *
 * @author Adrian
 */
public class Ejercicio2_TryCatchFinally {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FileReader reader = null;
        //String fileName = "/home/dam/NetBeansProjects/Ejercicio2_Try-Catch-Finally/probando.txt";
        //FileReader input = new FileReader(fileName);

        
        try {
            System.out.println("Introduce el nombre de in fichero: ");
            //String ficherotexto = sc.nextLine();
            String ficherotexto = "/home/dam/NetBeansProjects/Ejercicio2_Try-Catch-Finally/probando.txt";
            FileReader fr = new FileReader(ficherotexto);
            
            
            System.out.println("Abriendo fichero: "+ficherotexto);
            
        }catch (FileNotFoundException e){
            System.out.println("Fichero no encontrado");
        }finally {
            System.out.println("Fin de programa");
        }

        
        
        
    }
    
}
