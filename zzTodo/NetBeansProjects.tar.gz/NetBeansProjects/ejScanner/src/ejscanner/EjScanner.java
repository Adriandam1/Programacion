/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejscanner;
import java.util.Scanner;

/**
 *
 * @author Adrian
 */
// a continuacion van varios ejemplos de scanner
public class EjScanner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //area de un rectangulo = base * altura
/*        
       float base, altura, area;
        Scanner sc = new Scanner(System.in);
        System.out.print("El base es : ");
        base = sc.nextFloat();
        System.out.print("La altura es : ");
        altura = sc.nextFloat();
        area = base*altura;
        System.out.println("El area del rectangulo es = "+area);
*/        
        // calculo da lonxitude e area de un circulo lonxitude=2pi*radio(ra) s=n+r^2
        System.out.print("Teclea el radio del circulo: ");
        Scanner sc = new Scanner(System.in);
        float ra = sc.nextFloat();
            // para PI usamos el Math, como PI es double tenemos que hacer un cast a float
        float lonxitude = (float) (2*Math.PI*ra);
        System.out.println("La lonxitude do circulo e: "+lonxitude);
        
    }
    
}
