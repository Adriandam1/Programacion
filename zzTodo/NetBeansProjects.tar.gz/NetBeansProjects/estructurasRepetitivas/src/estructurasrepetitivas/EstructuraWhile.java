/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasrepetitivas;

/**
 *
 * @author Adrian
 */
public class EstructuraWhile {
    
    //codifica programa que amose 7 veces DAM1
    public void amosarWhile(){
        int i =0;
        while (i<7){
            System.out.println("DAM1 --> "+(i+1)); // ponemos +(i+1) para que nos indique en que vuelta estamos
            i ++;
        }
        System.out.println("Saimos do bucle");
    }
    
}
