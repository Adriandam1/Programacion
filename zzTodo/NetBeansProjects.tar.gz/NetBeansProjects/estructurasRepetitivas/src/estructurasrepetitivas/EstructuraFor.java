/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurasrepetitivas;

/**
 *
 * @author Adrian
 */
public class EstructuraFor {
    public void amosarFor(){
        for (int i = 0; i < 7; i++){
            System.out.println("DAM 1");
        }  
        System.out.println("Saimos do bucle");
    }
}
