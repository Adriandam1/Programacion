/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package coleccion_ejemplo_numeros;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Adrian
 */
public class Coleccion_ejemplo_numeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         //aqui esta el ejemplo Igor
        //Array tipo List de tipo integer
        List <Integer> numeros = new ArrayList<>();
        //Añadir elementos a la list numeros
        numeros.add(3);
        numeros.add(5);
        numeros.add(1);
        numeros.add(7);
        
        //Recorrer la lista y mostrar los nombres usando for
        // for que meta dentro de numero numeros, lo recorra y lo muestre por pantalla
        for ( Integer numero: numeros){
            System.out.println(numero+" Utilizando bucle for");
        }
        
        //Saca el numero seleccionado de la lista
        //System.out.println(numeros.get(0));
        
        //Saca primer numero de la lista
        //System.out.println(numeros.getFirst());
        //Saca ultimo numero de la lista
        //System.out.println(numeros.getLast());
        
        //Saca la lista entera
        System.out.println(numeros.toString()+" utilizando toString");
        
        //Borrar un elemento de la lista en una posicion concreta (en este caso borramos elemento en posicion1)
        //numeros.remove(1);
        
        //Borrar un elemento concreto independientemente de su posicion (en este caso borramos el elemento 5)
        numeros.remove(numeros.indexOf(5));
        
        //Si la lista es de String podemos elegir borrar un elemento espefico, independientemente de su posicion
        //numeros.remove(
        
        //Uso de contains en este caso para poner un mensaje si Marta esta en la lista
        //if (numeros.contains("Marta")){
         //   System.out.println("Marta esta en la lista");
        //}
        //Borra todos los elementos de la lista u el que se especifique
        //numeros.clear();
        
        //Saca la lista en orden inverso
         System.out.println(numeros.reversed());
         
         
         
         //Otra vez la lista entera
         System.out.println("Esta es "+numeros.toString());
    }
    
}
