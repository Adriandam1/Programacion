/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemploarrays;

/**
 *
 * @author Adrian
 */
public class EjemploArrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] Numeros=new int[3]; // Array de 3 números (posiciones del 0 al 2).
        Numeros[0]=99; // Primera posición del array.
        Numeros[1]=120; // Segunda posición del array.
        Numeros[2]=33; // Tercera y última posición del array.
        
        // El acceso a un valor ya existente dentro de una posición del array se consigue de forma similar, simplemente
        // poniendo el nombre del array y la posición a la cual se quiere acceder entre corchetes:        
        int suma=Numeros[0] + Numeros[1] + Numeros[2];
        System.out.println("Suma de los tres array: "+suma);
        
        // Para nuestra comodidad, los arrays, como objetos que son en Java, disponen de una propiedad pública muy útil.
        // La propiedad length nos permite saber el tamaño de cualquier array, lo cual es especialmente útil en métodos que
        // tienen como argumento un array.
        
        System.out.println("Longitud del array: "+Numeros.length);
        
        
    }
    
}
