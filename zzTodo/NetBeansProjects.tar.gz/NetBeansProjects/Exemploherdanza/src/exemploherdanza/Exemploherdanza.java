/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemploherdanza;

/**
 *
 * @author Adrian
 */
public class Exemploherdanza {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Creamos estudante: 
        String nom= LerDatos.lerString("tecla nome: ");
        String ap= LerDatos.lerString("teclea apelido: ");
        int ed = LerDatos.lerEnteiro("edade: ");
        float nota = LerDatos.lerFloatPositivo("nota: ");
        Estudante es = new Estudante(nota,nom,ap,ed);
        System.out.println(es);
        */
        
        /*Creamos persoa
        Persoa per = new Persoa(LerDatos.lerString("teclea nome"),LerDatos.lerString("teclea apelido: "),LerDatos.lerEnteiro("edade: "));
        System.out.println(per);
        */
        
        //Instanciamos un estudante de tipo persoa
        Persoa obx = new Estudante(5,"pepe","perez",15);
        System.out.println(obx);
        
        
    }
    
}
