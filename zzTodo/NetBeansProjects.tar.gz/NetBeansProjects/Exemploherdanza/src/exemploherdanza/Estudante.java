/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemploherdanza;

/**
 *
 * @author Adrian
 */
public class Estudante extends Persoa {
    
    private float notaFinal;

    public Estudante() {
    }

    public Estudante(float notaFinal) {
        this.notaFinal = notaFinal;
    }

    public Estudante(float notaFinal, String nome, String apelido, int edade) {
        super(nome, apelido, edade);
        this.notaFinal = notaFinal;
    }

    public float getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(float notaFinal) {
        this.notaFinal = notaFinal;
    }

    @Override
    public String toString() {
        return (super.toString()+"notaFinal=" + notaFinal);
    }

    
    
    
    
}
