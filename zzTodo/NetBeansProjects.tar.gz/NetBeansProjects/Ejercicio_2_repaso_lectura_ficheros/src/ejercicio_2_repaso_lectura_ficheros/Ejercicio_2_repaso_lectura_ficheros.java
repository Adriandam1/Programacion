/*
Enunciado 2: Lista de Tareas
Objetivo: Escribir un programa Java que lea un archivo llamado "tareas.txt", que contiene una lista de tareas pendientes, una tarea por línea. El programa debe enumerar las tareas al mostrarlas en la consola, comenzando por el número 1.

Descripción:

El archivo "tareas.txt" contiene tareas, una por línea (por ejemplo, "Hacer la compra", "Estudiar Java", etc.).
El programa debe leer este archivo y mostrar cada tarea en la consola con un número delante (1. Hacer la compra, 2. Estudiar Java, etc.).
Cierra el archivo después de leer todo su contenido.
Sugerencias:

Implementa la lectura del archivo con FileReader y BufferedReader.
Para enumerar las tareas, puedes usar una variable que incrementes con cada tarea leída en el bucle while.
Captura y maneja adecuadamente las excepciones que pueden surgir durante la operación de lectura del archivo.
 */
package ejercicio_2_repaso_lectura_ficheros;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Adrian
 */
public class Ejercicio_2_repaso_lectura_ficheros {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Ruta al archivo que queremos leer
        String rutaArchivo = "tareas.txt";
        
        

        try {
            // Abrir el archivo para leerlo
            FileReader fr = new FileReader(rutaArchivo);
            BufferedReader br = new BufferedReader(fr);

            String linea;
            int i=1;
            // Leer el archivo línea por línea
            while ((linea = br.readLine()) != null) {
                
                System.out.println(i++ +"- "+linea); // Imprimir cada línea
            }
            
            // Cerrar el archivo
            br.close();
        } catch (IOException e) {
            // Si ocurre un error, imprimir el mensaje de error
            System.out.println("Error leyendo el archivo: " + e.getMessage());
        }
    }
    
}

