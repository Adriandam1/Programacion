/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boletin7_1;

/**
 *
 * @author Adrian
 */
public class Positivo {
    
    public void ePositivo(int numero){
        if (numero>0)
            System.out.println("o numero "+numero+" e positivo");
    }
    
}
