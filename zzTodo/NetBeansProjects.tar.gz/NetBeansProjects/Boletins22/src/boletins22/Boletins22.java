/*1-  A seguinte táboa recolle lós goles marcados polos 20 equipos de 1ª  división en cada unha das 36 xornadas. 
Equipo/xornada    X1   X2     X3 ……
        Celta                 3     4        2
        Bilbao               1     2         1 
        Malaga              3     0        1
. Pídese: 
    1- Gravar e imprimir a táboa.
    2-  Obter unha listaxe dos equipos por orde de menor n° de goles na liga. 
    3-  Indicar o equipo que marca máis goles en cada xornada. 
    4-  Que equipo e en que xornada se rexistran máis goles? 
    5-  Consultas por equipo e xornada indicando o n° de goles. 
 */
package boletins22;

import java.util.Scanner;

/**
 *
 * @author Adrian
 */
public class Boletins22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String equipo="";
        String xornada="";
        //int suma = 0;
        //int maisgoles = 0;
        int maisgoles1 = 0;
        int maisgoles2 = 0;
        //int menosgoles = 0;
        Integer[][] goles = new Integer[3][3];
        
        // 1. Imprimiendo a taboa
        for (int i = 0; i < goles.length; i++) {
            if (i==0)
                equipo="Celta";
            else if (i==1)
                equipo="Bilbao";
            else if (i==2)
                equipo="Malaga";
        for (int j = 0; j < goles[i].length; j++) {
            if (j==0)
                xornada="X1";
            else if (j==1)
                xornada="X2";
            else if (j==2)
                xornada="X3";
        System.out.print("Goles do "+equipo+" na xornada "+xornada+" : ");
        goles[i][j] = sc.nextInt();}
        }
        
        System.out.println("\nEquipo/xornada\tX1\tX2\tX3...");
        
        for (int i = 0; i < goles.length; i++) {
            if (i==0)
                equipo="Celta";
            else if (i==1)
                equipo="Bilbao";
            else if (i==2)
                equipo="Malaga";
            System.out.print(equipo+"\t");
        for (int j = 0; j < goles[i].length; j++) {
            
        System.out.print("\t"+goles[i][j]+" ");            
        }System.out.println();
            
        }
        //3. Indicar o equipo que marca máis goles en cada xornada.
        /*
        for (int i = 0; i < goles.length; i++) {
        for (int j = 0; j < goles[i].length; j++) {
        /*if (j==0)
        equipo="Celta";
        else if (j==1)
        equipo="Bilbao";
        else if (j==2)
        equipo="Malaga";
        maisgoles = Math.max(maisgoles, goles[j][0]);
        maisgoles1 = Math.max(maisgoles, goles[j][1]);
        maisgoles2 = Math.max(maisgoles, goles[j][2]);
        //System.out.println("j: "+j+" "+" i:"+i);
        // Quiero hacer una variable equipo = posicion del valor mas alto del array que saca math.max
        }
        }        
        System.out.println("Maior goleador xornada1: "+equipo+" "+maisgoles+" con goles");
        System.out.println("Maior goleador xornada2: "+equipo+" "+maisgoles1+" con goles");
        System.out.println("Maior goleador xornada3: "+equipo+" "+maisgoles2+" con goles");
         */
        // Inicialización de variables para calcular la suma de todas las temperaturas,
        // la temperatura máxima registrada y la mínima registrada.
        int suma = 0; Double maisgoles = Double.MIN_VALUE, menosgoles = Double.MAX_VALUE;

        // Bucle que recorre cada día de la semana nuevamente.
        for (int i = 0; i < goles.length; i++) {
            // Suma de las temperaturas mínima y máxima del día 'i' a 'suma'.
            suma += (goles[i][0] + goles[i][1]);

            // Comprobación y actualización de la temperatura máxima registrada.
            // 'Math.max()' devuelve el valor más alto entre 'maxTemp' y la temperatura máxima del día 'i'.
            maisgoles = Math.max(maisgoles, goles[i][1]);

            // Comprobación y actualización de la temperatura mínima registrada.
            // 'Math.min()' devuelve el valor más bajo entre 'minTemp' y la temperatura mínima del día 'i'.
            menosgoles = Math.min(menosgoles, goles[i][0]);
        }


        // Impresión de los resultados: temperatura media, máxima y mínima.
        System.out.println("maisgoles: " + maisgoles);
        System.out.println("menosgoles: " + menosgoles);
        
        
        
    }
    
}
