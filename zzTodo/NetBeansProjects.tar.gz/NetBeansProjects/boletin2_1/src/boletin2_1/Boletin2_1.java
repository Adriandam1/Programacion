/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package boletin2_1;

/**
 *
 * @author Adrian
 */
public class Boletin2_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float base = 4, altura = 3, area;
        area = (base * altura)/2;
        System.out.println("Area do triangulo = "+area);
    }
    
}
