/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package boletin9_2;

/**
 *
 * @author Adrian
 */
public class Boletin9_2 {


    public static void main(String[] args) {
        
        SumaProducto obx = new SumaProducto();
        obx.sumaProducto(10, 90);
               
    }
    
}
