/*
Calcular a cantidade de numeros positivos, negativos e ceros que hay nun grupo de 10 numeros enteiros.
 */
package boletin9_1;


/**
 *
 * @author Adrian
 */
public class Boletin9_1 {

    public static void main(String[] args) {
            NumerosEnteiros obx = new NumerosEnteiros();
            obx.dezNumeros();        
        
    }
    
}
