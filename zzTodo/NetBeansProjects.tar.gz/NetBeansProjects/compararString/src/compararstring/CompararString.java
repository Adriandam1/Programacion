/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package compararstring;

import java.util.Objects;
import java.util.Scanner;

/**
 *
 * @author Adrian
 */
public class CompararString {

    /**
     * Comparar 2 String y ver si son o no iguales
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduza primer string: ");
        String a = sc.nextLine();
        System.out.println("Introduza segundo string: ");
        String b = sc.nextLine();

        if (Objects.equals(a, b)) {
         // iguales
            System.out.println("Los Strings son iguales");
        } else {
            // diferentes
            System.out.println("Los Strings son diferentes");
        }
    }
    
}
