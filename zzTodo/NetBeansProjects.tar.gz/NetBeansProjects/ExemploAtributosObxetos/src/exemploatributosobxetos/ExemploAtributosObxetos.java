/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemploatributosobxetos;

/**
 *
 * @author Adrian
 */
public class ExemploAtributosObxetos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Teclado obxT = new Teclado("Samsung", 80f);
        Rato obxR = new Rato("Logitech");
        Monitor obxM = new Monitor("Samsung", 15.5f);
        Ordenador ord1 =new Ordenador(obxT, obxR,obxM,800f);
        
        System.out.println(ord1);
        /*
        //otra manera de crear un ordenador sin necesidad de crear mas objetos
        Ordenador ord2 = new Ordenador(new Teclado("aa",20), new Rato("bbbb"), new Monitor("asus", 21f), 1000f);
        System.out.println(ord2);
        */
        //vamos desde ordenador a pantalla y a marca
        System.out.println("marca: "+ord1.getPantaia().getMarca());
        
        //cambiar precio de la pantalla a 150 y visualizar el pc con el nuevo precio
        obxT.setPrecio(150);
        System.out.println(ord1);
        
        
    }
    
}
