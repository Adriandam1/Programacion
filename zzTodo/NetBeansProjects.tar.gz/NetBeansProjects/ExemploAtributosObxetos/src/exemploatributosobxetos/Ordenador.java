/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemploatributosobxetos;

/**
 *
 * @author Adrian
 */
public class Ordenador {
    private Teclado tecla;
    private Rato raton;
    private Monitor pantaia;
    private float precio;

    public Ordenador() {
    }

    public Ordenador(Teclado tecla, Rato raton, Monitor pantaia, float precio) {
        this.tecla = tecla;
        this.raton = raton;
        this.pantaia = pantaia;
        this.precio = precio;
    }

    public Teclado getTecla() {
        return tecla;
    }

    public void setTecla(Teclado tecla) {
        this.tecla = tecla;
    }

    public Rato getRaton() {
        return raton;
    }

    public void setRaton(Rato raton) {
        this.raton = raton;
    }

    public Monitor getPantaia() {
        return pantaia;
    }

    public void setPantaia(Monitor pantaia) {
        this.pantaia = pantaia;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Ordenador{" + "tecla=" + tecla + ", raton=" + raton + ", pantaia=" + pantaia + ", precio=" + precio + '}';
    }
    
}
