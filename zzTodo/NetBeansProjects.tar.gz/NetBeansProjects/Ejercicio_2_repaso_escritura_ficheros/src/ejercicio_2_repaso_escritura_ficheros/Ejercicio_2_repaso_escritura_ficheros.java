/*
Enunciado 2: Lista de Compras
Objetivo: Desarrollar un programa en Java que genere una lista de compras en un archivo llamado "listaDeCompras.txt". El programa debe permitir al usuario añadir productos a la lista uno a uno.

Descripción:

Solicita al usuario que ingrese nombres de productos para la lista de compras.
El proceso termina cuando el usuario escribe "suficiente".
Cada producto ingresado se guarda en una nueva línea en el archivo "listaDeCompras.txt".
Sugerencias:

Emplea PrintWriter para una manera sencilla de escribir líneas de texto en el archivo.
Asegúrate de que cada nuevo producto se añada al archivo sin eliminar los productos previamente listados.
Maneja adecuadamente las excepciones para evitar errores en tiempo de ejecución.
 */
package ejercicio_2_repaso_escritura_ficheros;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Adrian
 */
public class Ejercicio_2_repaso_escritura_ficheros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
        // Definir el nombre del archivo donde se guardarán las tareas
        String nombreArchivo = "listaDeCompras.txt";
        String suficiente = "suficiente";
        String escribir;
        
        try {
            // Crear un objeto FileWriter para escribir en el archivo (sobrescribe el archivo si ya existe)
            FileWriter fw = new FileWriter(nombreArchivo, true);            
            // Envolver el FileWriter en BufferedWriter para una escritura más eficiente
            //BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(fw);
            
            do{
                System.out.println("añade algo al texto: ");
                escribir = sc.nextLine();
                if (!escribir.equals(suficiente))
                pw.write(escribir+"\n");
                else
                pw.close();
            }while (!suficiente.equals (escribir));
            
            
        }catch (IOException e) {
            // Capturar y mostrar errores que puedan ocurrir durante la escritura
            System.out.println("Ocurrió un error al escribir en el archivo: " + e.getMessage());
        }
    }
    
}

