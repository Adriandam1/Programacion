/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package diassemana;

import java.util.Scanner;

/**
 *
 * @author Adrian
 */
public class DiasSemana {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Semana obx = new Semana();
        Scanner sc = new Scanner(System.in);
        System.out.print("Escriba o dia da semana(1-7): ");
        int dia = sc.nextInt();
        obx.escollodia(dia);
        
    }
    
}
