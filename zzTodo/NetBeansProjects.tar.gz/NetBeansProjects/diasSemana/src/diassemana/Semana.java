/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diassemana;

/**
 *
 * @author Adrian
 */
public class Semana {
    public void escollodia(int dia){
        switch (dia) {
    case 1:
      System.out.println("Hoxe e Luns!");
      break;
    case 2:
      System.out.println("Hoxe e Martes!");
      break;
    case 3:
      System.out.println("Hoxe e Mercores!");
      break;
    case 4:
      System.out.println("Hoxe e Xoves!");
      break;
    case 5:
      System.out.println("Hoxe e Venres!");
      break;
    case 6:
      System.out.println("Hoxe e Sabado!");
      break;
    case 7:
      System.out.println("Hoxe e Domingo!");
      break;
      
    default:
      System.out.println("ERROR: o numero debe estar entre 1 e 7");
    }
    }
}
